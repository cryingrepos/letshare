@extends('parent')
@section('content')
@include('navs.hero')

@endsection