@extends('parent')
@section('content')
    <main id="main">
          <!-- ======= Breadcrumbs ======= -->
    <!--<section id="breadcrumbs" class="breadcrumbs">-->
    <!--  <div class="container">-->

    <!--    <ol>-->
    <!--      <li><a href="index.php">Home</a></li>-->
    <!--      <li>Background</li>-->
    <!--    </ol>-->
    <!--    <h2>Background</h2>-->

      <!--</div>-->
    <!--</section><!-- End Breadcrumbs -->

    <!-- ======= Frequently Asked Questions Section ======= -->

<section class="coming-soon">
    <div class="container">
        <div class="row justify-content-center align-items-center">
            <div class="col-12 justify-content-center align-items-center">
                <div class="coming-soon-content">
                    <h1>Coming soon </h1>
                <p>This page is under development.</p>

                <div class="social-links mt-3">
              <a href="https://twitter.com/i/flow/login" target="_blank" class="twitter"><i class="bx bxl-twitter"></i></a>
              <a href="https://www.facebook.com/login/" target="_blank" class="facebook"><i class="bx bxl-facebook"></i></a>
              <a href="https://www.instagram.com/accounts/login/" target="_blank" class="instagram"><i class="bx bxl-instagram"></i></a>
              <a href="https://www.linkedin.com/" target="_blank" class="linkedin"><i class="bx bxl-linkedin"></i></a>
            </div>
                </div>
            </div>
        </div>
    </div>
</section>
  </main><!-- End #main -->
@endsection
