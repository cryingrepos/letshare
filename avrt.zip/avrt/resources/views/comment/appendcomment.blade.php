let a_comment=` <div id="comment-1" class="comment">
    <div class="d-flex">
        <div class="comment-img"><img src="{{asset('img/blog-comment/Dakota.jpg')}}" alt="">
        </div>
        <div>
            <h5><a href="">*u</a> </h5>
            <time datetime="2020-01-01">*d</time>
            <p> *c</p>
            <div class="meta-top">
                <div class="like-rep">
                    <a href="javascript:void(0)" class="like-l"><i
                            class="fa-solid fa-thumbs-up"></i> 5 </a>
                    <a href="javascript:void(0)" class="reply-b"><i
                            class="bi bi-reply-fill"></i> Reply</a>
                    <div class="replay-box">
                        <form action="" class="reply-form">

                            <div class="row m-0 p-0">
                                <div class="col form-group">
                                    <textarea name="comment" class="form-control" placeholder="Add a reply*"></textarea>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary">Reply</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>`;
