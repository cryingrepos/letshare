let arena_reply=`
    <div id="comment-**id">
    <div class="d-flex">
        <div class="comment-img"><img src="/img/blog-comment/Dakota.jpg" alt="">
        </div>
        <div>
            <h5><a href="">*u</a> </h5>
            <time datetime="2020-01-01">*d</time>
            <p> *c</p>
            <div class="meta-top">
                <div class="like-rep">
                    <a href="javascript:void(0)" class="like-l"><i
                            class="fa-solid fa-thumbs-up"></i> 5 </a>
                    <a href="javascript:void(0)" class="reply-b"><i
                            class="bi bi-reply-fill"></i> Reply</a>
                            <a href="****" class="reply-d" ><i
                                                            class="bi bi-trash2"></i>Delete</a>
                    <div class="replay-box">
                        <form action="" class="reply-form">
                        <input type="hidden" name="comment_id" value="**c_id">
                            <div class="row m-0 p-0">
                                <div class="col form-group">
                                    <textarea name="comment" class="form-control" placeholder="Add a reply*"></textarea>
                                </div>
                            </div>
                            <button type="button" class="btn btn-primary reply_btn">Reply</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
</div>
</div>`;