<urlset
      xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
      xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
            http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
<!-- created with Free Online Sitemap Generator www.xml-sitemaps.com -->


<url>
  <loc>https://avrt.com/</loc>
  <lastmod>2023-01-25T04:02:45+00:00</lastmod>
  <priority>1.00</priority>
</url>
<url>
  <loc>https://avrt.com/avrt/faq</loc>
  <lastmod>2023-01-25T04:02:45+00:00</lastmod>
  <priority>0.80</priority>
</url>
<url>
  <loc>https://avrt.com/avrt/back</loc>
  <lastmod>2023-01-25T04:02:45+00:00</lastmod>
  <priority>0.80</priority>
</url>
<url>
  <loc>https://avrt.com/avrt/service</loc>
  <lastmod>2023-01-25T04:02:45+00:00</lastmod>
  <priority>0.80</priority>
</url>
<url>
  <loc>https://avrt.com/avrt/message</loc>
  <lastmod>2023-01-25T04:02:45+00:00</lastmod>
  <priority>0.80</priority>
</url>
<url>
  <loc>https://avrt.com/avrt/who-are-we</loc>
  <lastmod>2023-01-25T04:02:45+00:00</lastmod>
  <priority>0.80</priority>
</url>
<url>
  <loc>https://avrt.com/avrt/contact</loc>
  <lastmod>2023-01-25T04:02:45+00:00</lastmod>
  <priority>0.80</priority>
</url>
<url>
  <loc>https://avrt.com/avrt/post/come-on-lets-get-normal-again-in-great-america</loc>
  <lastmod>2023-01-25T04:02:45+00:00</lastmod>
  <priority>0.80</priority>
</url>


</urlset>