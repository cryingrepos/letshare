 <!-- ======= Header ======= -->
  <header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center">

      <!--<h1 class="logo me-auto"><a href="index.php"> AVRT</a></h1>-->
      <!-- Uncomment below if you prefer to use an image logo -->
       <a href="{{route('avrt.home')}}" class="logo me-auto"><img src="{{asset('img/Logo.png')}}" alt="" class="img-fluid"></a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="{{route('avrt.home')}}">Home</a></li>
          <li><a class="nav-link scrollto" href="{{route('avrt.faq')}}">FAQ</a></li>
          <li><a class="nav-link scrollto" href="{{route('avrt.back')}}">Background</a></li>
          <!--<li><a class="nav-link   scrollto" href="{{route('avrt.service')}}"><span> Services </span>  </a>-->
            <!--<ul>-->
            <!--  <li><a href="service-details.php">Teleconference</a></li>-->

            <!--  <li><a href="service-details.php">Apple-FaceTime/Android-Duo</a></li>-->

            <!--</ul>-->
          <!--</li>-->
          <!--href="{{route('avrt.message')}}"-->
          <li><a class="nav-link scrollto" href="{{route('avrt.message')}}" >Message</a></li>
          <li><a class="nav-link scrollto" href="{{route('avrt.who')}}">Who are We</a></li>
          <li><a class="nav-link scrollto" href="{{route('avrt.contact')}}">Contact Info</a></li>
            <li>
              <!--<a class="getstarted scrollto" href="contact.php"> Get Started</a>-->
           @if(Auth::check())
            <a class="nav-link scrollto" href="{{route('avrt.blog.create')}}">Blog</a>
           @endif
          </li>
          <li>
              <!--<a class="getstarted scrollto" href="contact.php"> Get Started</a>-->
           @if(Auth::check())
           <form action="{{route('auth.logout')}}" method="post">
            <button type="button" class="getstarted scrollto" onclick="this.form.submit()">Logout</button>
            @csrf
           </form>
           @else
           <button type="button" class="getstarted scrollto" data-bs-toggle="modal" data-bs-target="#exampleModal">Get Started</button>
           @endif
          </li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->
