<?php

namespace App\Http\Controllers\Main;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SeoSetting;
use App\CustomFacades\SEO;
class FAQController extends Controller
{
    public function main(){
        $meta=SeoSetting::where('slug','faq')->first();
        SEO::generateMeta($meta);
       // return view('main.faq');
         return view('main.background');
    }
}
