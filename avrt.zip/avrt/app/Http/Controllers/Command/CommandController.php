<?php

namespace App\Http\Controllers\Command;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
class CommandController extends Controller
{
    public function command(Request $request){
        system('composer dump-autoload');
     // Artisan::call('config:clear');
     //Artisan::call('make:event ArenaEvent');
    //Artisan::call('make:middleware ArenaSubscription');
    //Artisan::call('make:middleware VerifyAdmin');
    //Artisan::call('migrate:fresh');
     // Artisan::call('storage:link');
     //Artisan::call('optimize:clear');
     
   // Artisan::call('make:controller Auth/Social/SocialAuthController');
    //Artisan::call('make:controller Command/CommandController');
      //Artisan::call('make:model SeoSetting -m');
      //Artisan::call('make:controller Admin/CommentController --resource');
     // Artisan::call('make:controller Admin/Settings/PaypalController --resource');
      //Artisan::call('make:provider SeoProvider');
    //Artisan::call('make:controller Ideas/MembershipController');
    // Artisan::call('make:model Contact -m');
    //Artisan::call('make:migration alter_user_table_image --table=users');
     //Artisan::call('migrate:refresh --path=database/migrations/2023_01_27_062440_create_contacts_table.php');
    //database/migrations/2022_12_15_092945_create_payments_table.php;
    //Artisan::call('migrate:refresh --path=database/migrations/2022_12_15_092945_create_payments_table.php');
     // Artisan::call('make:mail PasswordMail');
    }
}
