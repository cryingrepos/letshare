<?php

namespace App\Http\Controllers\Ideas;

use App\Events\StrickOneEvent;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Exception;
use App\Models\Comments;
use App\Models\User;
use App\Models\Idea;
use App\Models\Batter;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use PhpParser\Comment;

class StrikeOneController extends Controller
{
    public function comment(Request $request){
        try {
            $first=false;
            $image="";
            if(!empty($request->data)){
                $user_id = "";
                $post=Idea::with('comments')->where('id', $request->data[2]['value'])->first();
                    if($post->comments->isEmpty()){
                      $first=true;  
                    }
                $user_exist= User::where('email', $request->data[1]['value'])->first();
                if($user_exist){
                    if(Auth::check()){
                        if($user_exist->email!=Auth::user()->email){
                           $data ='Please Subscribe To Arena To Post More Comments';
                           throw new Exception($data); 
                        }
                     }
                     $batter=Batter::where('user_id',$user_exist->id)->first();
                        if($batter){
                          $batter=Batter::where('user_id',$user_exist->id)->where('permission','arena')->first();
                          if(!$batter){
                           $data ='Please Subscribe To Arena To Post More Comments';
                           throw new Exception($data);    
                          }
                    }
                    $user_id=$user_exist->id;
                    $image=$user_exist->image;
                    $batter=new Batter();
                    $batter->user_id=$user_id;
                    $batter->post_id=$request->data[2]['value'];
                    $batter->permission="strike_one";
                    $batter->save();
                 }else{
                      if(Auth::check()){
                        if($request->data[1]['value']!=Auth::user()->email){
                           $data ='Please Subscribe To Arena To Post More Comments';
                           throw new Exception($data); 
                        }
                      }
                    $user = new User();
                    $user->name = $request->data[0]['value'];
                    $user->email = $request->data[1]['value'];
                    $user->password = Hash::make($user->name.'@avrt');
                    $user->role = '2';
                    $image_array=['avatars/g1.png','avatars/b2.png','avatars/g3.png','avatars/b4.png','avatars/b5.png','avatars/g6.png'];
                    $key=array_rand($image_array);
                    $image=$image_array[$key];
                    $user->image=$image;
                    $user->save();
                    $user_id=$user->id;
                    $batter=new Batter();
                    $batter->user_id=$user_id;
                    $batter->post_id=$request->data[2]['value'];
                    $batter->permission="strike_one";
                    $batter->save();
                 }
                $comment = new Comments();
                $comment->idea_id = $request->data[2]['value'];
                $comment->content = $request->data[3]['value'];
                $comment->user_id = $user_id;
                $comment->save();
                event(new StrickOneEvent($comment));
                return response()->json([
                    'code' => '200',
                    'msg'=>'Comment Posted SuccessFully',
                    'data'=>$comment,
                    'name'=>$comment->user->name,
                    'first'=>$first,
                    'img'=>$image,
                    'date'=>date('d M Y',strtotime($comment->created_at))
                ]);
            }
        } catch (Exception $ex) {
            return response()->json([
                'code' => '201',
                'msg'=>'Comment Posting Failed',
                'error'=>$ex->getMessage()
            ]);
        }
    }

}
